This project demonstrates for teaching and research purposes
how to use CUDA and GAs to learn to play Blackjack, that is,
to learn the basic strategy.